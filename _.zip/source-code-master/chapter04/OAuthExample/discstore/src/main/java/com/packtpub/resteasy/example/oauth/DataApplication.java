package com.packtpub.resteasy.example.oauth;

import javax.ws.rs.ApplicationPath;
import javax.ws.rs.core.Application;

/**
 * 
 * @author Andres
 * 
 */
@ApplicationPath("/")
public class DataApplication extends Application {
}
